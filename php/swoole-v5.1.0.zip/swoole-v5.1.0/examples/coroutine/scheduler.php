<?php
Co\Run(function () {
    Co::sleep(0.2);
    echo "hello world\n";
});