<?php
$table = new Swoole\Table(65536);
var_dump($table);
var_dump(class_implements($table));
